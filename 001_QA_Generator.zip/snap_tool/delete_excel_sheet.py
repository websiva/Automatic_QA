import openpyxl

def delete_sheets_except_wanted(workbook, wanted_sheets):
    all_sheet_names = workbook.sheetnames
    for sheet_name in all_sheet_names:
        if sheet_name not in wanted_sheets:
            workbook.remove(workbook[sheet_name])

excel_file_path = "E:\\001_QA_Generator\\snap_tool\\convert.xlsx"
workbook = openpyxl.load_workbook(excel_file_path)

wanted_sheets = ['Conversions']

delete_sheets_except_wanted(workbook, wanted_sheets)

workbook.save(excel_file_path)