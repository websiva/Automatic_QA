#!/usr/bin/python3
# Copyright (c) Catalog Data Solutions. All Rights Reserved.
#
# CDS CAD server simulation and batch trail file creation/execution utility.

import sys
import os
import subprocess
import time
import re
from openpyxl import load_workbook


class TrailManager:
    """Reads CAD data and lists of Creo operations from an Excel spreadsheet,
    and generates trail files for each of the desired operations.
    """
    def __init__(self, filename):
        self.workbook = load_workbook(filename=filename, read_only=True,
                                      data_only=True)
        self.cad_data = {}
        self.operations = []
        self.top_template = None
        self.mid_template = None
        self.bot_template = None
        self.ppbatch = None


    def load(self, mode=None):
        """Read all worksheets into cad_data and operations."""
        for sheet in self.workbook.worksheets:
            if sheet.title == 'Batch':
                if mode != 'conversion':
                    self.load_operations(sheet)
            elif sheet.title == 'Conversions':
                if mode == 'conversion':
                    self.load_conversions(sheet)
            else:
                if mode != 'conversion':
                    for rowno in range(1, 100):
                        v = sheet.cell(row=rowno, column=1).value
                        if v == "Generic Model Path":
                            self.load_cad_data(sheet, rowno)
                            break


    def load_cad_data(self, sheet, row):
        """Reads the operations worksheet listing all CAD to be generated
        during this execution.  Reading ends on the first line without all
        required values.
        """
        i = row
        model_path = None
        instance = None
        drawing_path = None
        regens = 1
        parameter_names = []
        instance_col = 0
        while True:
            v = sheet.cell(row=i, column=1).value
            if v == "Generic Model Path":
                model_path = sheet.cell(row=i, column=2).value
            elif v == "Drawing Path":
                drawing_path = sheet.cell(row=i, column=2).value
            elif v == "# of Regens":
                regens = int(sheet.cell(row=i, column=2).value)
            elif v == "Product ID":
                for j in range(2, 500):
                    vv = sheet.cell(row=i, column=j).value
                    if vv == 'Instance':
                        instance_col = j
                    elif vv is None:
                        break
                    parameter_names.append(vv)
                break
            i += 1

        while True:
            i += 1
            parameters = []
            pid = sheet.cell(row=i, column=1).value
            if pid is None:
                break
            for j in range(2, len(parameter_names) + 2):
                v = sheet.cell(row=i, column=j).value
                if j == instance_col:
                    instance = v
                elif v is not None:
                    parameters.append({'name': parameter_names[j-2],
                                       'value': str(v)})
            self.cad_data[pid] = {'model_path': model_path,
                                  'instance': instance,
                                  'drawing_path': drawing_path,
                                  'parameters': parameters,
                                  'regens': regens}


    def load_operations(self, sheet):
        """Reads the operations worksheet listing all CAD to be generated
        during this execution.  Reading ends on the first line without all
        required values.
        """
        self.top_template = None
        self.mid_template = None
        self.bot_template = None
        self.ppbatch = None
        i = 1
        started = False
        cols = []
        while not started:
            k = sheet.cell(row=i, column=1).value
            v = sheet.cell(row=i, column=2).value
            if k == "Top Template":
                self.top_template = v
            elif k == "Middle Template":
                self.mid_template = v
            elif k == "Bottom Template":
                self.bot_template = v
            elif k == "Parts per Batch":
                self.ppbatch = v
            elif k == "Product ID":
                for j in range(2, 500):
                    vv = sheet.cell(row=i, column=j).value
                    if vv is None:
                        break
                    cols.append(vv)
                break
            i += 1

        while True:
            i += 1
            pid = sheet.cell(row=i, column=1).value
            fmt = None
            path = None
            wilds = []
            for j in range(2, len(cols) + 2):
                v = sheet.cell(row=i, column=j).value
                if cols[j-2] == 'Format':
                    fmt = v
                elif cols[j-2] == 'Output File':
                    path = v
                else:
                    if v is not None:
                        wilds.append({'name': cols[j-2], 'value': str(v)})
                    else:
                        wilds.append({'name': cols[j-2], 'value': None})
            if pid is not None and fmt is not None and path is not None:
                self.operations.append({'pid': pid, 'fmt': fmt, 'path': path,
                                        'wilds': wilds})
            else:
                break


    def load_conversions(self, sheet):
        """Reads the conversions worksheet listing all CAD to be generated
        during this execution.  Reading ends on the first line without all
        required values.
        """
        self.top_template = None
        self.mid_template = None
        self.bot_template = None
        self.ppbatch = None
        i = 1
        started = False
        cols = []
        while not started:
            k = sheet.cell(row=i, column=1).value
            v = sheet.cell(row=i, column=2).value
            if k == "Top Template":
                self.top_template = v
            elif k == "Middle Template":
                self.mid_template = v
            elif k == "Bottom Template":
                self.bot_template = v
            elif k == "Parts per Batch":
                self.ppbatch = v
            elif k == "Source Path":
                for j in range(2, 500):
                    vv = sheet.cell(row=i, column=j).value
                    if vv is None:
                        break
                    cols.append(vv)
                break
            i += 1

        while True:
            i += 1
            pid = sheet.cell(row=i, column=1).value
            fmt = ''
            instance = None
            drawing_path = None
            path = None
            wilds = []
            for j in range(2, len(cols) + 2):
                v = sheet.cell(row=i, column=j).value
                if cols[j-2] == 'Instance':
                    instance = v
                elif cols[j-2] == 'Drawing Path':
                    drawing_path = v
                elif cols[j-2] == 'Destination Path':
                    path = v
                else:
                    if v is not None:
                        wilds.append({'name': cols[j-2], 'value': str(v)})
                    else:
                        wilds.append({'name': cols[j-2], 'value': None})
            if pid is not None and path is not None:
                self.operations.append({'pid': pid, 'fmt': fmt, 'path': path,
                                        'wilds': wilds})
                self.cad_data[pid] = {'model_path': pid,
                                      'instance': instance,
                                      'drawing_path': drawing_path,
                                      'parameters': []}
            else:
                break


    def write_cgs_trail_file(self, operation):
        """Write standard trail file for given operation.
        Uses trail file templates from CGS model server.
        """
        pid = operation['pid']
        cad = self.cad_data[pid]
        if cad is None:
            return None

        fmt = operation['fmt']
        path = operation['path']
        template_top_path = 'templates/'
        template_bot_path = 'templates/'
        model_path = cad['model_path']
        instance = cad['instance']
        drawing_path = cad['drawing_path']
        igs_path = os.getcwd() + '\\_cgs_temp_igs'
        parameters = cad['parameters']
        is_assembly = '.asm' in model_path

        # no drawing path for dxf- formats
        if (fmt == 'dxf-default' or fmt == 'dxf-front' or fmt == 'dxf-top'
                or fmt == 'dxf-iso' or fmt == 'dxf-right'):
            drawing_path = None
        # these formats we create new assembly and add part to it
        if (fmt == 'qadxf' or fmt == 'dxf' or fmt == 'obj' or fmt == '2djpg'
                or fmt == 'dxf-default' or fmt == 'dxf-front'
                or fmt == 'dxf-top' or fmt == 'dxf-iso' or fmt == 'dxf-right'):
            if instance is not None and len(parameters) > 0:
                template_top_path += 'prt_inst_parm_comp.txt'
            elif instance is not None:
                template_top_path += 'prt_inst_comp.txt'
            elif len(parameters) > 0:
                template_top_path += 'prt_parm_comp.txt'
            else:
                template_top_path += 'prt_comp.txt'
        # special dynamic 2D PDF
        elif fmt == '2dpdfd':
            template_top_path += 'drw_inst_parm.txt'
        # sales drawings
        elif fmt == 'drw-dxf' or fmt == 'drw-pdf':
            if len(parameters) > 0:
                template_top_path += 'drw_asm_note_param.txt'
            else:
                template_top_path += 'drw_asm_note.txt'
        # assembly to part
        elif fmt == 'prt' and is_assembly:
            if instance is not None and len(parameters) > 0:
                template_top_path += 'asm_inst_parm.txt'
            elif instance is not None:
                template_top_path += 'asm_inst.txt'
            elif len(parameters) > 0:
                template_top_path += 'asm_parm.txt'
            else:
                template_top_path += 'asm.txt'
        # parts and assemblies to other formats
        else:
            if instance is not None and len(parameters) > 0:
                template_top_path += 'prt_inst_parm.txt'
            elif instance is not None:
                template_top_path += 'prt_inst.txt'
            elif len(parameters) > 0:
                template_top_path += 'prt_parm.txt'
            else:
                template_top_path += 'prt.txt'

        # output formats
        if fmt == 'prt':
            template_bot_path += 'to_prt.txt'
        elif fmt == 'zip':
            template_bot_path += 'to_zip.txt'
        elif fmt == 'neu':
            template_bot_path += 'to_neu.txt'
        elif fmt == 'stp':
            template_bot_path += 'to_stp.txt'
        elif fmt == 'igs':
            template_bot_path += 'to_igs.txt'
        elif fmt == 'x_t':
            template_bot_path += 'to_x_t.txt'
        elif fmt == 'stl':
            template_bot_path += 'to_stl.txt'
        elif fmt == 'sat':
            template_bot_path += 'to_sat.txt'
        elif fmt == 'jpgwire':
            template_bot_path += 'to_jpgwire.txt'
        elif fmt == 'qadxf':
            template_bot_path += 'to_qadxf.txt'
        elif fmt == 'dxf-default':
            template_bot_path += 'to_dxf.txt'
        elif fmt == 'dxf-front':
            template_bot_path += 'to_dxf_front.txt'
        elif fmt == 'dxf-right':
            template_bot_path += 'to_dxf_right.txt'
        elif fmt == 'dxf-top':
            template_bot_path += 'to_dxf_top.txt'
        elif fmt == 'dxf-iso':
            template_bot_path += 'to_dxf_iso.txt'
        elif fmt == '3dpdf':
            template_bot_path += 'to_pdf.txt'
        elif fmt == 'u3d':
            template_bot_path += 'to_u3d.txt'
        elif fmt == 'dwg':
            template_bot_path += 'to_dwg.txt'
        elif fmt == 'obj':
            template_bot_path += 'to_obj.txt'
        elif fmt == 'webgl':
            template_bot_path += 'to_webgl.txt'
        else:
            if drawing_path is None:
                if fmt == 'dxf':
                    template_bot_path += 'to_dxf.txt'
                elif fmt == 'pdf':
                    template_bot_path += 'to_pdf.txt'
                elif fmt == '2dpdfd':
                    template_bot_path += 'to_2dpdfd.txt'
                elif fmt == 'jpg':
                    template_bot_path += 'to_jpg.txt'
                elif fmt == '2djpg':
                    template_bot_path += 'to_2djpg-notemplate.txt'
                else:
                    print('Invalid output format:', fmt, flush=True)
            else:
                if fmt == 'dxf':
                    template_bot_path += 'to_2ddxf.txt'
                elif fmt == 'pdf':
                    template_bot_path += 'to_2dpdf.txt'
                elif fmt == '2dpdf':
                    template_bot_path += 'to_2dpdf.txt'
                elif fmt == 'jpg':
                    template_bot_path += 'to_2djpg.txt'
                elif fmt == '2djpg':
                    template_bot_path += 'to_2djpg.txt'
                elif fmt == 'drw-dxf':
                    template_bot_path += 'to_drw-dxf.txt'
                elif fmt == 'drw-pdf':
                    template_bot_path += 'to_drw-pdf.txt'
                else:
                    print('Invalid output format:', fmt, flush=True)

        with open(template_top_path, 'r') as f:
            trail = f.read()
            trail += '\n'
        with open(template_bot_path, 'r') as f:
            trail += f.read()

        model_path = os.path.join(os.getcwd(), model_path.replace('/', '\\'))
        trail = trail.replace('<% SOURCE MODEL %>',
                model_path.replace('\\', '\\\\'))
        trail = trail.replace('<% SOURCE MODEL DIR %>',
                os.path.dirname(model_path).replace('\\', '\\\\'))
        trail = trail.replace('<% SOURCE MODEL NAME %>',
                os.path.basename(model_path).replace('\\', '\\\\'))
        trail = trail.replace('<% DESTINATION MODEL %>',
                os.path.join(os.getcwd(),
                path.replace('/', '\\')).replace('\\', '\\\\'))
        trail = trail.replace('<% TEMP MODEL %>',
                igs_path.replace('\\', '\\\\'))
        if instance is not None:
            trail = trail.replace('<% INSTANCE %>', instance)
        if drawing_path is not None:
            trail = trail.replace('<% DRAWING %>', os.path.join(os.getcwd(),
                    drawing_path.replace('/', '\\')).replace('\\', '\\\\'))
        params = ''
        if len(parameters) > 0:
            if fmt != '2dpdfd':
                params += '~ Command `ProCmdMmParams` \n'
            for p in parameters:
                params += '#MODIFY\n'
                if instance is not None:
                    params += '#CONFIRM\n'
                params += '#'
                params += p['name']
                params += '\n'
                params += p['value']
                params += '\n'
            params += '#DONE/RETURN\n'
            params += '#DONE/RETURN\n'
            if (is_assembly or fmt == 'dxf' or fmt == 'qadxf'
                    or fmt == 'dxf-default' or fmt == 'dxf-front'
                    or fmt == 'dxf-top' or fmt == 'dxf-iso'
                    or fmt == 'dxf-right'):
                for i in range(cad['regens']):
                    params += '~ Command `ProCmdRegenAuto` \n'
            elif fmt == '2dpdfd':
                params += ('~ Activate `main_dlg_cur` '
                           '`page_Review_control_btn` 1\n')
                params += '~ Command `ProCmdDwgRegenModel` \n'
                params += '~ Command `ProCmdDwgUpdateSheets` \n'
            else:
                for i in range(cad['regens']):
                    params += '~ Command `ProCmdRegenPart` \n'
            trail = trail.replace('<% PARAMETERS %>', params)
        trail = re.sub('\n+', '\n', trail)

        with open('trail-' + pid + '.txt', 'w') as f:
            f.write(trail + '\n')


    def write_batch_trail_file(self, operations, trail_name):
        """Writes trail file for batch operation.  Uses custom trail files
        defined within the operations tab of the workbook.
        """
        with open(self.top_template, 'r') as f:
            t = f.read()
        trail = self.parse_batch_trail_file(operations[0], t)
        with open(self.mid_template, 'r') as f:
            t = f.read()
        for o in operations:
            trail += self.parse_batch_trail_file(o, t)
        with open(self.bot_template, 'r') as f:
            t = f.read()
        trail += self.parse_batch_trail_file(operations[0], t)
        trail = trail.replace('\n\n', '\n')
        with open(trail_name, 'w') as f:
            f.write(trail)


    def parse_batch_trail_file(self, operation, trail):
        """Replaces all variables within a custom trail file with the data from
        the curren operation.
        """
        pid = operation['pid']
        cad = self.cad_data[pid]
        fmt = ''
        path = ''
        model_path = ''
        vault_path = ''
        model_name = ''
        instance = ''
        drawing_path = ''
        if operation['fmt'] is not None:
            fmt = operation['fmt']
        if operation['path'] is not None:
            path = os.path.join(os.getcwd(),
                    operation['path'].replace('/', '\\'))
        if cad['model_path'] is not None:
            model_path = os.path.join(os.getcwd(),
                    cad['model_path'].replace('/', '\\'))
        if model_path is not None:
            vault_path = os.path.dirname(model_path)
            model_name = os.path.basename(model_path)
        if cad['instance'] is not None:
            instance = cad['instance']
        if cad['drawing_path'] is not None:
            drawing_path = os.path.join(os.getcwd(),
                    cad['drawing_path'].replace('/', '\\'))
        igs_path = os.getcwd() + '\\_cgs_temp_igs'
        is_assembly = '.asm' in model_path
        parameters = cad['parameters']
        params = ''
        if len(parameters) > 0:
            if fmt != '2dpdfd':
                params += '~ Command `ProCmdMmParams` \n'
            for p in parameters:
                params += '#MODIFY\n'
                params += '#'
                params += p['name']
                params += '\n'
                params += p['value']
                params += '\n'
            params += '#DONE/RETURN\n'
            params += '#DONE/RETURN\n'
            if (is_assembly or fmt == 'dxf' or fmt == 'qadxf'
                    or fmt == 'dxf-default' or fmt == 'dxf-front'
                    or fmt == 'dxf-top' or fmt == 'dxf-iso'
                    or fmt == 'dxf-right'):
                for i in range(cad['regens']):
                    params += '~ Command `ProCmdRegenAuto` \n'
            elif fmt == '2dpdfd':
                params += ('~ Activate `main_dlg_cur` '
                           '`page_Review_control_btn` 1\n')
                params += '~ Command `ProCmdDwgRegenModel` \n'
                params += '~ Command `ProCmdDwgUpdateSheets` \n'
            else:
                for i in range(cad['regens']):
                    params += '~ Command `ProCmdRegenPart` \n'

        t = trail.replace('<% PRODUCT %>', pid)
        t = t.replace('<% FORMAT %>', fmt)
        t = t.replace('<% DESTINATION MODEL %>', path.replace('\\', '\\\\'))
        t = t.replace('<% SOURCE MODEL %>', model_path.replace('\\', '\\\\'))
        t = t.replace('<% SOURCE MODEL DIR %>',
                      vault_path.replace('\\', '\\\\'))
        t = t.replace('<% SOURCE MODEL NAME %>', model_name)
        t = t.replace('<% INSTANCE %>', instance)
        t = t.replace('<% DRAWING %>', drawing_path.replace('\\', '\\\\'))
        t = t.replace('<% TEMP MODEL %>', igs_path.replace('\\', '\\\\'))
        t = t.replace('<% PARAMETERS %>', params)
        for w in operation['wilds']:
            if w['value'] is not None:
                t = t.replace('<% V:' + w['name'] + ' %>', w['value'])
            else:
                t = t.replace('<% V:' + w['name'] + ' %>', '')
        return t


def usage():
    """Show application help message"""
    print('generate-cad.py [-hbcgd] [delay] <input_spreadsheet> '
          '<creo_executable_path>')
    print('CAD server simulation utility.')
    print('Example: py generate-cad.py cad.xlsx "C:\\Program Files\\PTC\\Creo '
          '2.0\\Parametric\\bin\\parametric.exe"')
    print('         (on linux): generate-cad.py -gd 0 cad.xlsx ignored')
    print()
    print('Options:')
    print('   -h, --help        Show help')
    print('   -b, --batch       Invoke batch mode using operations tab')
    print('   -c, --convert     Invoke convert mode using conversions tab')
    print('   -d, --delay SEC   Delay SEC seconds in between each Creo '
          'execution')
    print('                     (default 3 seconds)')
    print('   -g, --debug       Generates all trail files, does not execute '
          'Creo')


def main(argv):
    batch_mode = False
    convert_mode = False
    debug_mode = False
    input_filename = None
    creo_executable = None
    process_delay = 3
    next_delay = False
    for a in argv:
        if next_delay:
            try:
                process_delay = int(a)
            except:
                usage()
                sys.exit(0)
            next_delay = False
        elif a.startswith('-'):
            if a.startswith('--'):
                a = a[2:]
                if a == 'help':
                    usage()
                    sys.exit(0)
                elif a == 'batch':
                    batch_mode = True
                elif a == 'convert':
                    convert_mode = True
                elif a == 'delay':
                    next_delay = True
                elif a == 'debug':
                    debug_mode = True
            for c in a[1:]:
                if c == 'h':
                    usage()
                    sys.exit(0)
                elif c == 'b':
                    batch_mode = True
                elif c == 'c':
                    convert_mode = True
                elif c == 'd':
                    next_delay = True
                elif c == 'g':
                    debug_mode = True
        else:
            if input_filename is None:
                input_filename = a
            else:
                creo_executable = a
    if input_filename is None or creo_executable is None:
        usage()
        sys.exit(0)

    print('Reading input spreadsheet', input_filename, flush=True)
    manager = TrailManager(input_filename)
    if batch_mode:
        manager.load('batch')
    elif convert_mode:
        manager.load('conversion')
    else:
        manager.load()


    if batch_mode:
        ops = []
        i = 0
        j = 0
        for o in manager.operations:
            print('Adding {} to CAD batch'.format(o['pid']), flush=True)
            sys.stdout.flush()
            ops.append(o)
            i += 1
            if i >= manager.ppbatch:
                print('Executing current batch...', end='', flush=True)
                j += 1
                trail_name = 'trail-' + str(j) + '.txt'
                manager.write_batch_trail_file(ops, trail_name)
                if not debug_mode:
                    proc = subprocess.run(args=[creo_executable, trail_name])
                ops = []
                i = 0
                if process_delay > 0:
                    time.sleep(process_delay)
                print('Done', flush=True)
        if len(ops) > 0:
            print('Executing current batch...', end='', flush=True)
            j += 1
            trail_name = 'trail-' + str(j) + '.txt'
            manager.write_batch_trail_file(ops, trail_name)
            if not debug_mode:
                proc = subprocess.run(args=[creo_executable, trail_name])
            if process_delay > 0:
                time.sleep(process_delay)
            print('Done', flush=True)
    elif convert_mode:
        ops = []
        i = 0
        j = 0
        for o in manager.operations:
            print('Adding {} to CAD batch'.format(o['pid']), flush=True)
            sys.stdout.flush()
            ops.append(o)
            i += 1
            if i >= manager.ppbatch:
                print('Executing current batch...', end='', flush=True)
                j += 1
                trail_name = 'trail-' + str(j) + '.txt'
                manager.write_batch_trail_file(ops, trail_name)
                if not debug_mode:
                    proc = subprocess.run(args=[creo_executable, trail_name])
                ops = []
                i = 0
                if process_delay > 0:
                    time.sleep(process_delay)
                print('Done', flush=True)
        if len(ops) > 0:
            print('Executing current batch...', end='', flush=True)
            j += 1
            trail_name = 'trail-' + str(j) + '.txt'
            manager.write_batch_trail_file(ops, trail_name)
            if not debug_mode:
                proc = subprocess.run(args=[creo_executable, trail_name])
            if process_delay > 0:
                time.sleep(process_delay)
            print('Done', flush=True)
    else:
        for o in manager.operations:
            print('Generating CAD for {}...'.format(o['pid']), end='',
                  flush=True)
            sys.stdout.flush()
            manager.write_cgs_trail_file(o)
            if not debug_mode:
                proc = subprocess.run(args=[creo_executable, 'trail-' +
                                      o['pid'] + '.txt'])
            if process_delay > 0:
                time.sleep(process_delay)
            print('Done', flush=True)
    print('Done')


if __name__ == "__main__":
    main(sys.argv[1:])
