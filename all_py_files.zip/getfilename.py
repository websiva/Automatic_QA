import os
import pandas as pd
import glob
import openpyxl

file_name = "E:\QA_Generator\input.xlsx"
load_wb = openpyxl.load_workbook(file_name, data_only=True)
load_ws = load_wb['Sheet1']
row_count = load_ws.max_row

j=1
while(j<=row_count):
    part_number=(str(load_ws.cell(row=j,column=1).value))+"_sldprt"
    product_id=str(load_ws.cell(row=j,column=1).value)
    directory = f"E://QA_Generator//snap_tool//input//sldprt//{part_number}"
    excel_file = "E://QA_Generator//snap_tool//convert.xlsx"

    file_names = []

    for file in os.listdir(directory):
        file_names.append(file)

    wb = openpyxl.load_workbook(excel_file)
    ws = wb.create_sheet(product_id)

    row = 1
    col = 1
    for name in file_names:
        ws.cell(row, col).value = name
        row += 1
    wb.save(excel_file)
    j+=1

