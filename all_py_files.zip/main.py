import subprocess
import time
from openpyxl import load_workbook

subprocess.run("getfilename.py", shell=True)
time.sleep(2)
subprocess.run("takeSnap.py", shell=True)
time.sleep(2)
subprocess.run("save_excel.bat", shell=True)
