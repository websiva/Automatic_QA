from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
from selenium.webdriver.support.ui import Select
import time
from openpyxl import load_workbook 
import pyscreenshot as ImageGrab
import os

file_name = "E:\QA_Generator\input.xlsx"
load_wb = load_workbook(file_name, data_only=True)
load_ws = load_wb['Sheet1']
row_count = load_ws.max_row

download_directory="E:\QA_Generator\downloaded_pdf"
options = webdriver.ChromeOptions()
options.add_experimental_option('prefs', {
"download.default_directory":download_directory,
"download.prompt_for_download": False, #To auto download the file
"download.directory_upgrade": True,
"plugins.always_open_pdf_externally": True #It will not show PDF directly in chrome
})
driver = webdriver.Chrome("E:\QA_Generator\chromedriver_win32\chromedriver.exe",options=options)

def downloadPdf():
    i=1
    driver.get('https://qa.product-config.net/catalog3/d/grainger/?c=products&cid=root&id=38YN54')
    driver.maximize_window()
    driver.implicitly_wait(5)
    email=driver.find_element(By.ID,"cds-login-email")
    email.send_keys("c-skumar6@cdsvisual.com")
    password=driver.find_element(By.ID,"cds-login-passwd")
    password.send_keys("R7GXgpUASEwU")
    login_button=driver.find_element(By.TAG_NAME,'button').click()
    driver.implicitly_wait(5)
    while(i<=row_count):
        part_number=load_ws.cell(row=i,column=1).value
        driver.get("https://qa.product-config.net/catalog3/d/grainger/?c=products&cid=root&id="+str(part_number))
        cad = driver.find_element(By.ID,"cds-cad-download-formats")
        select_cad=Select(cad)
        select_cad.select_by_index(1)
        driver.implicitly_wait(5)
        download_cad=driver.find_element(By.ID,"cds-cad-download-button")
        download_cad.click()
        driver.implicitly_wait(200)
        time.sleep(2)
        driver.find_element(By.XPATH,"/html/body/div[4]/div[2]/div[2]/a").click()
        driver.implicitly_wait(5)
        driver.find_element(By.XPATH,"/html/body/div[4]/div[1]/button/span[1]").click()
        time.sleep(3)
        im=ImageGrab.grab(bbox=(110,350,655,820))
        directory=f"E:\\QA_Generator\\png_images\\{part_number}"
        if not os.path.exists(directory):
            os.mkdir(directory)
        snip_directory=f"E:\\QA_Generator\\png_images\\{part_number}\\"
        file_nmae=part_number+'_json'
        file_save_name=snip_directory+file_nmae+'.png'
        im.save(file_save_name)
        i+=1
    time.sleep(2)
    driver.close()

def main():
    downloadPdf()
   
if __name__ == "__main__":
    main()
      







        




