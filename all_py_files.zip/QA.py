from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
from selenium.webdriver.support.ui import Select
from openpyxl import load_workbook
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support.wait import WebDriverWait
from threading import Thread
from win32com.client.dynamic import Dispatch
from pptx import Presentation 
from pptx.util import Inches
from pptx.util import Inches, Pt
from pptx.dml.color import ColorFormat, RGBColor
from pptx.enum.dml import MSO_COLOR_TYPE, MSO_THEME_COLOR
import pyscreenshot as ImageGrab
import shutil
import openpyxl
import time
import os
import subprocess

def downloadPrt():
    download_directory="E:\\001_QA_Generator\\downloaded_files\\prt_files"
    options = webdriver.ChromeOptions()
    options.add_experimental_option('prefs', {
    "download.default_directory":download_directory,
    "download.prompt_for_download": False, #To auto download the file
    "download.directory_upgrade": True,
    "plugins.always_open_pdf_externally": True #It will not show PDF directly in chrome
    })
    driver = webdriver.Chrome("E:\\001_QA_Generator\\chromedriver_win32\\chromedriver.exe",options=options)

    driver.get('https://qa.product-config.net/catalog3/d/grainger/?c=products&cid=root&id=38YN54')
    driver.maximize_window()
    driver.implicitly_wait(5)
    email=driver.find_element(By.ID,"cds-login-email")
    email.send_keys("c-skumar6@cdsvisual.com")
    password=driver.find_element(By.ID,"cds-login-passwd")
    password.send_keys("R7GXgpUASEwU")
    login_button=driver.find_element(By.TAG_NAME,'button').click()
    driver.implicitly_wait(5)

    file_name = "E:\\001_QA_Generator\\input.xlsx"
    load_wb = load_workbook(file_name, data_only=True)
    load_ws = load_wb['Sheet1']
    row_count = load_ws.max_row

    i=1
    while(i<=row_count):
        part_number=load_ws.cell(row=i,column=1).value
        driver.get("https://qa.product-config.net/catalog3/d/grainger/?c=products&cid=root&id="+str(part_number)) 
        driver.implicitly_wait(10)    
        cad = driver.find_element(By.ID,"cds-cad-download-formats")
        select_cad=Select(cad)
        select_cad.select_by_index(5)
        time.sleep(1)
        driver.find_element(By.ID,"cds-cad-download-button").click()
        driver.implicitly_wait(200)
        time.sleep(1)
        driver.find_element(By.XPATH,('//*[@id="cds-cad-request-dialog"]/table/tbody/tr/td[2]/div[2]')).click()
        wait = WebDriverWait(driver, 100)
        wait.until(lambda x: any(filename.endswith('.zip')
            for filename in os.listdir(download_directory)))
        time.sleep(1)
        file_to_copy = 'E:/001_QA_Generator/downloaded_files/prt_files/grainger-'+part_number+'.zip'
        destination_directory = 'E:/001_QA_Generator/snap_tool/input/prt'
        shutil.move(file_to_copy, destination_directory)
        shutil.unpack_archive('E:/001_QA_Generator/snap_tool/input/prt/grainger-'+part_number+'.zip', 'E:/001_QA_Generator/snap_tool/input/prt/'+part_number+'_prt')
        os.remove('E:/001_QA_Generator/snap_tool/input/prt/grainger-'+part_number+'.zip')
        i+=1
    time.sleep(2)
    driver.close()

def downloadSimp():
    download_directory="\\001_QA_Generator\\downloaded_files\\simp_files"
    options = webdriver.ChromeOptions()
    options.add_experimental_option('prefs', {
    "download.default_directory":download_directory,
    "download.prompt_for_download": False, #To auto download the file
    "download.directory_upgrade": True,
    "plugins.always_open_pdf_externally": True #It will not show PDF directly in chrome
    })
    driver = webdriver.Chrome("E:\\001_QA_Generator\\chromedriver_win32\\chromedriver.exe",options=options)

    driver.get('https://qa.product-config.net/catalog3/d/grainger/?c=products&cid=root&id=38YN54')
    driver.maximize_window()
    driver.implicitly_wait(5)
    email=driver.find_element(By.ID,"cds-login-email")
    email.send_keys("c-skumar6@cdsvisual.com")
    password=driver.find_element(By.ID,"cds-login-passwd")
    password.send_keys("R7GXgpUASEwU")
    login_button=driver.find_element(By.TAG_NAME,'button').click()
    driver.implicitly_wait(5)

    file_name = "E:\\001_QA_Generator\\input.xlsx"
    load_wb = load_workbook(file_name, data_only=True)
    load_ws = load_wb['Sheet1']
    row_count = load_ws.max_row

    i=1
    while(i<=row_count):
        part_number=load_ws.cell(row=i,column=1).value
        driver.get("https://qa.product-config.net/catalog3/d/grainger/?c=products&cid=root&id="+str(part_number))        
        cad = driver.find_element(By.ID,"cds-cad-download-formats")
        select_cad=Select(cad)
        select_cad.select_by_index(3)
        time.sleep(1)
        driver.find_element(By.ID,"cds-cad-download-button").click()
        driver.implicitly_wait(200)
        time.sleep(1)
        driver.find_element(By.XPATH,('//*[@id="cds-cad-request-dialog"]/table/tbody/tr/td[2]/div[2]')).click()
        wait = WebDriverWait(driver, 200)
        wait.until(lambda x: any(filename.endswith('.zip')
        for filename in os.listdir(download_directory)))
        time.sleep(1)
        file_to_copy = 'E:/001_QA_Generator/downloaded_files/simp_files/grainger-'+part_number+'.zip'
        destination_directory = 'E:/001_QA_Generator/snap_tool/input/stp_simp'
        shutil.move(file_to_copy, destination_directory)
        shutil.unpack_archive('E:/001_QA_Generator/snap_tool/input/stp_simp/grainger-'+part_number+'.zip', 'E:/001_QA_Generator/snap_tool/input/stp_simp/'+part_number+'_simp')
        os.remove('E:/001_QA_Generator/snap_tool/input/stp_simp/grainger-'+part_number+'.zip')
        i+=1
    time.sleep(1)
    driver.close()

def downloadSldprt():
    download_directory="E:\\001_QA_Generator\\downloaded_files\\sldprt_files"
    options = webdriver.ChromeOptions()
    options.add_experimental_option('prefs', {
    "download.default_directory":download_directory,
    "download.prompt_for_download": False, #To auto download the file
    "download.directory_upgrade": True,
    "plugins.always_open_pdf_externally": True #It will not show PDF directly in chrome
    })
    driver = webdriver.Chrome("E:\\001_QA_Generator\\chromedriver_win32\\chromedriver.exe",options=options)

    driver.get('https://qa.product-config.net/catalog3/d/grainger/?c=products&cid=root&id=38YN54')
    driver.maximize_window()
    driver.implicitly_wait(5)
    email=driver.find_element(By.ID,"cds-login-email")
    email.send_keys("c-skumar6@cdsvisual.com")
    password=driver.find_element(By.ID,"cds-login-passwd")
    password.send_keys("R7GXgpUASEwU")
    login_button=driver.find_element(By.TAG_NAME,'button').click()
    driver.implicitly_wait(5)

    file_name = "E:\\001_QA_Generator\\input.xlsx"
    load_wb = load_workbook(file_name, data_only=True)
    load_ws = load_wb['Sheet1']
    row_count = load_ws.max_row

    i=1
    while(i<=row_count):
        part_number=load_ws.cell(row=i,column=1).value
        driver.get("https://qa.product-config.net/catalog3/d/grainger/?c=products&cid=root&id="+str(part_number))
        cad = driver.find_element(By.ID,"cds-cad-download-formats")
        select_cad=Select(cad)
        select_cad.select_by_index(4)
        time.sleep(1)
        driver.find_element(By.ID,"cds-cad-download-button").click()
        driver.implicitly_wait(200)
        time.sleep(1)
        driver.find_element(By.XPATH,('//*[@id="cds-cad-request-dialog"]/table/tbody/tr/td[2]/div[2]')).click()
        wait = WebDriverWait(driver, 200)
        wait.until(lambda x: any(filename.endswith('.zip')
            for filename in os.listdir(download_directory)))
        time.sleep(1)
        file_to_copy = 'E:/001_QA_Generator/downloaded_files/sldprt_files/grainger-'+part_number+'.zip'
        destination_directory = 'E:/001_QA_Generator/snap_tool/input/sldprt'
        shutil.move(file_to_copy, destination_directory)
        shutil.unpack_archive('E:/001_QA_Generator/snap_tool/input/sldprt/grainger-'+part_number+'.zip', 'E:/001_QA_Generator/snap_tool/input/sldprt/'+part_number+'_sldprt')
        os.remove('E:/001_QA_Generator/snap_tool/input/sldprt/grainger-'+part_number+'.zip')
        i+=1
    time.sleep(1)
    driver.close()

def downloadpdf():
    file_name = "E:\\001_QA_Generator\\input.xlsx"
    load_wb = load_workbook(file_name, data_only=True)
    load_ws = load_wb['Sheet1']
    row_count = load_ws.max_row

    download_directory="E:\\001_QA_Generator\\downloaded_files\\downloaded_pdf"
    options = webdriver.ChromeOptions()
    options.add_experimental_option('prefs', {
    "download.default_directory":download_directory,
    "download.prompt_for_download": False, #To auto download the file
    "download.directory_upgrade": True,
    "plugins.always_open_pdf_externally": True #It will not show PDF directly in chrome
    })
    driver = webdriver.Chrome("E:\\001_QA_Generator\\chromedriver_win32\\chromedriver.exe",options=options)

    i=1
    driver.get('https://qa.product-config.net/catalog3/d/grainger/?c=products&cid=root&id=38YN54')
    driver.maximize_window()
    driver.implicitly_wait(5)
    email=driver.find_element(By.ID,"cds-login-email")
    email.send_keys("c-skumar6@cdsvisual.com")
    password=driver.find_element(By.ID,"cds-login-passwd")
    password.send_keys("R7GXgpUASEwU")
    login_button=driver.find_element(By.TAG_NAME,'button').click()
    driver.implicitly_wait(5)
    while(i<=row_count):
        part_number=load_ws.cell(row=i,column=1).value
        driver.get("https://qa.product-config.net/catalog3/d/grainger/?c=products&cid=root&id="+str(part_number))
        cad = driver.find_element(By.ID,"cds-cad-download-formats")
        select_cad=Select(cad)
        select_cad.select_by_index(1)
        driver.implicitly_wait(5)
        download_cad=driver.find_element(By.ID,"cds-cad-download-button")
        download_cad.click()
        driver.implicitly_wait(200)
        time.sleep(2)
        driver.find_element(By.XPATH,"/html/body/div[4]/div[2]/div[2]/a").click()
        driver.implicitly_wait(5)
        driver.find_element(By.XPATH,"/html/body/div[4]/div[1]/button/span[1]").click()
        time.sleep(3)
        im=ImageGrab.grab(bbox=(110,350,655,820))
        directory=f"E:\\001_QA_Generator\\png_images\\{part_number}"
        if not os.path.exists(directory):
            os.mkdir(directory)
        snip_directory=f"E:\\001_QA_Generator\\png_images\\{part_number}\\"
        file_nmae=part_number+'_json'
        file_save_name=snip_directory+file_nmae+'.png'
        im.save(file_save_name)
        i+=1
    time.sleep(2)
    driver.close()

def getfilename():
    file_name = "E:\\001_QA_Generator\\input.xlsx"
    load_wb = openpyxl.load_workbook(file_name, data_only=True)
    load_ws = load_wb['Sheet1']
    row_count = load_ws.max_row

    j=1
    while(j<=row_count):
        part_number=(str(load_ws.cell(row=j,column=1).value))+"_sldprt"
        product_id=str(load_ws.cell(row=j,column=1).value)
        directory = f"E://001_QA_Generator//snap_tool//input//sldprt//{part_number}"
        excel_file = "E://001_QA_Generator//snap_tool//convert.xlsx"

        file_names = []

        for file in os.listdir(directory):
            file_names.append(file)

        wb = openpyxl.load_workbook(excel_file)
        ws = wb.create_sheet(product_id)

        row = 1
        col = 1
        for name in file_names:
            ws.cell(row, col).value = name
            row += 1
        wb.save(excel_file)
        j+=1

def openPdfInPdfViewer():
    file_name = "E:\\001_QA_Generator\\input.xlsx"
    load_wb = load_workbook(file_name, data_only=True)
    load_ws = load_wb['Sheet1']
    row_count = load_ws.max_row

    j=1
    while(j<=row_count):
        part_number=str(load_ws.cell(row=j,column=1).value)
        path=f"E:\\001_QA_Generator\\downloaded_pdf\\grainger-{part_number}.pdf"
        src = os.path.abspath(path)
        app = Dispatch("AcroExch.AVDoc")
        app.Open(src, src)
        im=ImageGrab.grab(bbox=(425,205,1470,980))
        directory=f"E:\\001_QA_Generator\\png_images\\{part_number}"
        if not os.path.exists(directory):
            os.mkdir(directory)
        snip_directory=f"E:\\001_QA_Generator\\png_images\\{part_number}\\"
        file_nmae=part_number+'_pdf'
        file_save_name=snip_directory+file_nmae+'.png'
        im.save(file_save_name)
        j=j+1
    time.sleep(2)
    app.Close(-1)

def saveExcel():
    subprocess.run("E:\\001_QA_Generator\\all_py_files\\save_excel.bat", shell=True)

def openCreoBat():
    subprocess.run("E:\\001_QA_Generator\\all_py_files\\03_snap_from_creo.bat", shell=True)

def getPPT():
    file_name = "E:\\001_QA_Generator\\input.xlsx"

    load_wb = load_workbook(file_name, data_only=True)
    load_ws = load_wb['Sheet1']
    row_start=1
    row_count = load_ws.max_row
    i=1

    slide_number = 1
    X = Presentation()
    X.slide_width = Inches(16)
    X.slide_height = Inches(9)
    Second_Layout = X.slide_layouts[6]

    while(i<=row_count):
        part_number=load_ws.cell(row=row_start,column=1).value
        heading=load_ws.cell(row=row_start,column=2).value
        second_slide = X.slides.add_slide(Second_Layout)
        logo=second_slide.shapes.add_picture("E:\\001_QA_Generator\\logo.png",Inches(13.8), Inches(0.05),width=Inches(2.07),height = Inches(0.77))
        #------------------------heading-------------------------#
        textbox = second_slide.shapes.add_textbox(Inches(1.5), Inches(0.15),Inches(11), Inches(0.5))
        textframe = textbox.text_frame
        paragraph = textframe.add_paragraph()
        paragraph.text = str(heading)
        paragraph.font.size=Pt(38)
        paragraph.font.bold = True
        paragraph.font.color.rgb = RGBColor(0, 109, 117)    
        #------------------slide no-------------------#
        textbox = second_slide.shapes.add_textbox(Inches(0.5), Inches(1.5),Inches(0.5), Inches(1.5))
        textframe = textbox.text_frame
        paragraph = textframe.add_paragraph()
        paragraph.text = str(slide_number)
        paragraph.font.bold = True
        paragraph.font.color.rgb = RGBColor(255,255,255)    
        textbox.fill.solid()
        textbox.fill.fore_color.rgb = RGBColor(0, 109, 117)
        #-------------------JSON----------------#
        png_name=part_number+"_json.png"
        image=second_slide.shapes.add_picture(f"E:\\001_QA_Generator\\png_images\\{part_number}\\{png_name}", Inches(1.25), Inches(2.2),height = Inches(2),width=Inches(2))
        textbox = second_slide.shapes.add_textbox(Inches(1.75), Inches(1.25),Inches(0.2), Inches(0.2))
        textframe = textbox.text_frame
        paragraph = textframe.add_paragraph()
        paragraph.text = "JSON"
        paragraph.font.bold = True
        paragraph.font.color.rgb = RGBColor(0, 109, 117)

        #-------------SIMP_STP-------------------#
        png_name=part_number+"_simp.png"
        image=second_slide.shapes.add_picture(f"E:\\001_QA_Generator\\png_images\\{part_number}\\{png_name}", Inches(4.75), Inches(2.2),height = Inches(2),width=Inches(2))
        textbox = second_slide.shapes.add_textbox(Inches(5), Inches(1.25),Inches(0.2), Inches(0.2))
        textframe = textbox.text_frame
        paragraph = textframe.add_paragraph()
        paragraph.text = "SIMP_STP"
        paragraph.font.bold = True
        paragraph.font.color.rgb = RGBColor(0, 109, 117)
        #-----------------SWX--------------------#
        png_name=part_number+"_sldprt.png"
        image=second_slide.shapes.add_picture(f"E:\\001_QA_Generator\\png_images\\{part_number}\\{png_name}", Inches(1.25), Inches(5.5),height = Inches(2),width=Inches(2))
        textbox = second_slide.shapes.add_textbox(Inches(1.75), Inches(4.5),Inches(0.2), Inches(0.2))
        textframe = textbox.text_frame
        paragraph = textframe.add_paragraph()
        paragraph.text = "SWX"
        paragraph.font.bold = True
        paragraph.font.color.rgb = RGBColor(0, 109, 117)
        #------------------PRT-------------------#
        png_name=part_number+"_prt.png"
        image=second_slide.shapes.add_picture(f"E:\\001_QA_Generator\\png_images\\{part_number}\\{png_name}", Inches(4.75), Inches(5.5),height = Inches(2),width=Inches(2))
        textbox = second_slide.shapes.add_textbox(Inches(5.25), Inches(4.5),Inches(0.2), Inches(0.2))
        textframe = textbox.text_frame
        paragraph = textframe.add_paragraph()
        paragraph.text = "PRT"
        paragraph.font.bold = True
        paragraph.font.color.rgb = RGBColor(0, 109, 117)
        #---------------2dpdf--------------------#
        pdf_name=part_number+"_pdf.png"
        image=second_slide.shapes.add_picture(f"E:\\001_QA_Generator\\png_images\\{part_number}\\{pdf_name}", Inches(7.5), Inches(2.1),height = Inches(5.5),width=Inches(8))
        textbox = second_slide.shapes.add_textbox(Inches(11), Inches(1.25),Inches(0.2), Inches(0.2))
        textframe = textbox.text_frame
        paragraph = textframe.add_paragraph()
        paragraph.text = "2dpdf"
        paragraph.font.bold = True
        paragraph.font.color.rgb = RGBColor(0, 109, 117)
        #-------------------bottom link------------
        textbox = second_slide.shapes.add_textbox(Inches(1.25), Inches(8),Inches(0.3), Inches(11))
        textframe = textbox.text_frame
        paragraph = textframe.add_paragraph()
        paragraph.text = f"https://qa.product-config.net/catalog3/d/grainger/?c=products&cid=root&id={part_number}"
        paragraph.font.size=Pt(18)
        paragraph.font.bold = True
        paragraph.font.color.rgb = RGBColor(0, 109, 117)

        slide_number+=1
        row_start+=1
        i+=1

    X.save("E:\\001_QA_Generator\\First_presentation.pptx")


def downloadAllfromSite():
    Thread(target=downloadPrt).start()
    Thread(target=downloadSimp).start()
    Thread(target=downloadSldprt).start()
    Thread(target=downloadpdf).start()
   
def main():
    downloadAllfromSite()
    getfilename()
    openPdfInPdfViewer()
    saveExcel()
    openCreoBat()
    getPPT()
    
    
if __name__ == "__main__":
    main()