import os

os.system("main_prt.py,main_simp.py")
#os.system("main_simp.py &")
#os.system("main_sldprt.py &")
#os.system("pdf_download_take_json_snip_tool.py ")

