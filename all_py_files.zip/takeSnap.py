import subprocess
from openpyxl import load_workbook
import time, csv , json
import pyscreenshot as ImageGrab
import os
from win32com.client.dynamic import Dispatch


file_name = "E:\QA_Generator\input.xlsx"
load_wb = load_workbook(file_name, data_only=True)
load_ws = load_wb['Sheet1']
row_count = load_ws.max_row
web_scraping=True

def openPdfInPdfViewer():
    j=2
    while(j<=row_count):
        part_number=str(load_ws.cell(row=j,column=1).value)
        path=f".\downloaded_files\downloaded_pdf\grainger-{part_number}.pdf"
        acrobat_path = "C:\Program Files (x86)\Adobe\Acrobat 2020\Acrobat\Acrobat.exe" 
        app=subprocess.Popen([acrobat_path, path], shell=True)
        im=ImageGrab.grab(bbox=(425,205,1470,980))
        directory=f"E:\\001_QA_Generator\\png_images\\{part_number}"
        if not os.path.exists(directory):
            os.mkdir(directory)
        snip_directory=f"E:\\001_QA_Generator\\png_images\\{part_number}\\"
        file_nmae=part_number+'_pdf'
        file_save_name=snip_directory+file_nmae+'.png'
        im.save(file_save_name)
        j=j+1
    time.sleep(2)
    app.close(-1)

def main():
    openPdfInPdfViewer()
     
if __name__ == "__main__":
    main()