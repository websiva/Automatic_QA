import os

os.system("E:\\QA_Generator\\snap_tool\\prt\\convert_creo4.0.bat")
os.system("E:\\QA_Generator\\snap_tool\\sldprt\\convert_creo4.0.bat")
os.system("E:\\QA_Generator\\snap_tool\\stp_simp\\convert_creo4.0.bat")
