from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
from selenium.webdriver.support.ui import Select
import time
import os
from openpyxl import load_workbook
import shutil
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support.wait import WebDriverWait

download_directory="E:\QA_Generator\prt_files"
options = webdriver.ChromeOptions()
options.add_experimental_option('prefs', {
"download.default_directory":download_directory,
"download.prompt_for_download": False, #To auto download the file
"download.directory_upgrade": True,
"plugins.always_open_pdf_externally": True #It will not show PDF directly in chrome
})
driver = webdriver.Chrome("E:\QA_Generator\chromedriver_win32\chromedriver.exe",options=options)

driver.get('https://qa.product-config.net/catalog3/d/grainger/?c=products&cid=root&id=38YN54')
driver.maximize_window()
driver.implicitly_wait(5)
email=driver.find_element(By.ID,"cds-login-email")
email.send_keys("c-skumar6@cdsvisual.com")
password=driver.find_element(By.ID,"cds-login-passwd")
password.send_keys("R7GXgpUASEwU")
login_button=driver.find_element(By.TAG_NAME,'button').click()
driver.implicitly_wait(5)

file_name = "E:\QA_Generator\input.xlsx"
load_wb = load_workbook(file_name, data_only=True)
load_ws = load_wb['Sheet1']
row_count = load_ws.max_row

i=8
while(i<=row_count):
    part_number=load_ws.cell(row=i,column=1).value
    driver.get("https://qa.product-config.net/catalog3/d/grainger/?c=products&cid=root&id="+str(part_number)) 
    driver.implicitly_wait(10)    
    cad = driver.find_element(By.ID,"cds-cad-download-formats")
    select_cad=Select(cad)
    select_cad.select_by_index(5)
    time.sleep(1)
    driver.find_element(By.ID,"cds-cad-download-button").click()
    driver.implicitly_wait(200)
    time.sleep(1)
    driver.find_element(By.XPATH,('//*[@id="cds-cad-request-dialog"]/table/tbody/tr/td[2]/div[2]')).click()
    wait = WebDriverWait(driver, 100)
    wait.until(lambda x: any(filename.endswith('.zip')
        for filename in os.listdir(download_directory)))
    time.sleep(1)
    file_to_copy = 'E:/QA_Generator/prt_files/grainger-'+part_number+'.zip'
    destination_directory = 'E:/QA_Generator/snap_tool/input/prt'
    shutil.move(file_to_copy, destination_directory)
    shutil.unpack_archive('E:/QA_Generator/snap_tool/input/prt/grainger-'+part_number+'.zip', 'E:/QA_Generator/snap_tool/input/prt/'+part_number+'_prt')
    os.remove('E:/QA_Generator/snap_tool/input/prt/grainger-'+part_number+'.zip')
    i+=1
time.sleep(2)
driver.close()


